import UIKit

var greeting = "Hello, playground"


var fact = "swift is a type safe language"
var dev = "development of swift began in 2010"
var author = "swift was created by Chris Lattner"

fact.count

fact += ", it has a better memory management"

dev.append(" by apple")

author.lowercased()

author.uppercased()

author[author.index(before: author.endIndex)]

author[author.index(after: author.startIndex)]

author[author.index(author.startIndex,offsetBy: 5)]

author[author.index(author.endIndex,offsetBy: -5)]

fact[fact.index(fact.endIndex,offsetBy: -4)]



var shoppinglist = "The shopping list contains: "
var fooditems = "cheese, butter, chocolate spread"
var clothes = "socks, T-shirts"


if clothes.hasPrefix("socks"){
    print("The first item in clotes is socks")
}else{
    print("socks is not the first item in clothes")
}


print(fooditems.split(separator: ","))

if clothes.contains(","){
    print("clothes contains more than one item")
}else{
    print("clothes contain only one item")
}

fooditems[fooditems.startIndex..<fooditems.index(fooditems.endIndex,offsetBy: -7)]




