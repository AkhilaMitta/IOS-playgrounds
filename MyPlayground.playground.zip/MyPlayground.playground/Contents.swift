import UIKit

var greeting = "Hello, playground"
var i = 10;
print(i)

print("Hi",10,10.25)
var name = "Akhila"
print("Hello, \(name)")
var age = 23;
print("my age is \(age) and in the next \(age) years it would be \(age*2)")

print("""
hello
world
i am
here
in maryville
""")

print("Hello all,\rwelcome to swift programming")

let welcomemessage : String="hello"
print(welcomemessage,"all")

print("welcome to swift programming", terminator:"-")
print("fall 2022")

print(1,2,3,4,5,6,separator:"-")

